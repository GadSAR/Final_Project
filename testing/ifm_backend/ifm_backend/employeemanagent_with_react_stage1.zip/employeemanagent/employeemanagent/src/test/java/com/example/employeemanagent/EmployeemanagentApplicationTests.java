package com.example.employeemanagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemanagentApplicationTests {

	@Test
	void contextLoads() {
	}

}
