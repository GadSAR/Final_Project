package com.example.employeemanagent.service;

import com.example.employeemanagent.model.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeServiceInterface {
    List<Employee> getAllEmployees();
    Employee saveEmployee(Employee employee);

    Optional<Employee> getEmployeeById(Long id);

    Employee updateEmployee(Long id, Employee employee);

    void deleteStudent(Long id);
}
