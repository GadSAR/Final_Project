package com.example.employeemanagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeemanagentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeemanagentApplication.class, args);
	}

}
